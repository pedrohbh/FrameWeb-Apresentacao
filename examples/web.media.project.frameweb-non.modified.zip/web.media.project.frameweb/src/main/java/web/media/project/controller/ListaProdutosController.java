package web.media.project.controller;

import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(value = "session")
@Component(value = "listaProdutosController")
@ELBeanName(value = "listaProdutosController")
@Join(path = "FROM", to = "TO")
public class ListaProdutosController {

	@Autowired
	private ProdutoService produtoService;

	private List produtos;

	public void loadData() {
		// TODO Auto-generated method stub
		return;
	}

	public List getProdutos() {
		return produtos;
	}

	public void setProdutos(List produtos) {
		this.produtos = produtos;
	}

}