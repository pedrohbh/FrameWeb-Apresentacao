package web.media.project.repository;

import org.springframework.stereotype.Repository;
import javax.persistence.PersistenceContext;

@Repository
public class ProdutoRepositoryImpl implements ProdutoRepository {

	@PersistenceContext
	EntityManager entityManager;

}