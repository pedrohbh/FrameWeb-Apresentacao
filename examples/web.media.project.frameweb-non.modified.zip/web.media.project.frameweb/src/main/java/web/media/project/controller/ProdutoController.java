package web.media.project.controller;

import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(value = "session")
@Component(value = "produtoController")
@ELBeanName(value = "produtoController")
@Join(path = "FROM", to = "TO")
public class ProdutoController {

	@Autowired
	private ProdutoService produtoService;

	private Produto produto;

	public String save() {
		// TODO Auto-generated method stub
		return null;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

}